import { CELL_TYPES } from '../engine/GameState.js';

export class IsometricRenderer {
    constructor(canvas, container) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');
        this.container = container;
        
        // Settings for Dimetric projection (2:1 pixel art style)
        this.tileWidth = 64;
        this.tileHeight = 32;
        this.floorHeight = 16;
        
        this.offsetX = 0;
        this.offsetY = 0;

        this.resize();
        window.addEventListener('resize', () => this.resize());
    }

    resize() {
        this.canvas.width = this.container.clientWidth;
        this.canvas.height = this.container.clientHeight;
        
        // Center the grid
        this.offsetX = this.canvas.width / 2;
        this.offsetY = this.canvas.height / 4;
        
        // Initial render if state exists
        if (this.lastState) {
            this.render(this.lastState);
        }
    }

    getScreenCoords(gridX, gridY, floor = 0) {
        const sx = (gridX - gridY) * (this.tileWidth / 2) + this.offsetX;
        const sy = (gridX + gridY) * (this.tileHeight / 2) + this.offsetY - (floor * this.floorHeight);
        return { x: sx, y: sy };
    }

    render(state) {
        this.lastState = state;
        
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Painter's Algorithm: Draw from top-left (0,0) down to bottom-right
        // First draw base grid
        for (let y = 0; y < state.height; y++) {
            for (let x = 0; x < state.width; x++) {
                this.drawTile(x, y, state.grid[y][x]);
            }
        }

        // Draw targets (footprints)
        for (let y = 0; y < state.height; y++) {
            for (let x = 0; x < state.width; x++) {
                if (state.grid[y][x] === CELL_TYPES.TARGET) {
                    this.drawTargetIndicator(x, y);
                }
            }
        }

        // Draw Map Boundaries
        this.drawMapBoundaries(state);

        // Draw restaurants (sort by Y then X for correct isometric overlap)
        const sortedRestaurants = [...state.restaurants].sort((a, b) => {
            if (a.x + a.y === b.x + b.y) {
                // If same depth, sort by id to be deterministic, though they shouldn't overlap
                return a.id - b.id; 
            }
            return (a.x + a.y) - (b.x + b.y);
        });

        for (const rest of sortedRestaurants) {
            this.drawRestaurant(rest);
        }
    }

    drawTile(x, y, type) {
        const coords = this.getScreenCoords(x, y);
        this.ctx.beginPath();
        this.ctx.moveTo(coords.x, coords.y - this.tileHeight / 2); // Top
        this.ctx.lineTo(coords.x + this.tileWidth / 2, coords.y); // Right
        this.ctx.lineTo(coords.x, coords.y + this.tileHeight / 2); // Bottom
        this.ctx.lineTo(coords.x - this.tileWidth / 2, coords.y); // Left
        this.ctx.closePath();

        // Get colors from CSS vars
        const styles = getComputedStyle(document.body);
        
        let fillStyle = styles.getPropertyValue('--color-land');
        if (type === CELL_TYPES.ROAD) fillStyle = styles.getPropertyValue('--color-road');
        if (type === CELL_TYPES.BLOCKER) fillStyle = styles.getPropertyValue('--color-blocker');
        if (type === CELL_TYPES.TARGET) fillStyle = styles.getPropertyValue('--color-target'); // Make target a distinct floor color

        this.ctx.fillStyle = fillStyle;
        this.ctx.fill();
        
        // Grid outline
        this.ctx.strokeStyle = 'rgba(0,0,0,0.2)';
        this.ctx.lineWidth = 1;
        this.ctx.stroke();
    }

    drawTargetIndicator(x, y) {
        const coords = this.getScreenCoords(x, y);
        this.ctx.beginPath();
        // Inner diamond for target footprint "O"
        const offset = 8;
        this.ctx.moveTo(coords.x, coords.y - this.tileHeight / 2 + offset); 
        this.ctx.lineTo(coords.x + this.tileWidth / 2 - offset*2, coords.y);
        this.ctx.lineTo(coords.x, coords.y + this.tileHeight / 2 - offset); 
        this.ctx.lineTo(coords.x - this.tileWidth / 2 + offset*2, coords.y);
        this.ctx.closePath();

        this.ctx.strokeStyle = '#ffffff';
        this.ctx.lineWidth = 2;
        this.ctx.setLineDash([4, 4]); // Dashed line to look like blueprint/target
        this.ctx.stroke();
        this.ctx.setLineDash([]); // Reset
        this.ctx.lineWidth = 1;
    }

    drawMapBoundaries(state) {
        this.ctx.strokeStyle = '#ffffff';
        this.ctx.lineWidth = 2;
        
        // Top edge
        const topCoords = this.getScreenCoords(0, 0);
        const rightCoords = this.getScreenCoords(state.width - 1, 0);
        const bottomCoords = this.getScreenCoords(state.width - 1, state.height - 1);
        const leftCoords = this.getScreenCoords(0, state.height - 1);

        this.ctx.beginPath();
        // Top vertex
        this.ctx.moveTo(topCoords.x, topCoords.y - this.tileHeight / 2);
        // Right vertex
        this.ctx.lineTo(rightCoords.x + this.tileWidth / 2, rightCoords.y);
        // Bottom vertex
        this.ctx.lineTo(bottomCoords.x, bottomCoords.y + this.tileHeight / 2);
        // Left vertex
        this.ctx.lineTo(leftCoords.x - this.tileWidth / 2, leftCoords.y);
        this.ctx.closePath();
        this.ctx.stroke();
        this.ctx.lineWidth = 1;
    }

    drawRestaurant(rest) {
        // Draw floors from bottom to top
        for(let f = 0; f < rest.floors; f++) {
            const baseCoords = this.getScreenCoords(rest.x, rest.y, f);
            const topY = baseCoords.y - this.floorHeight; 
            
            // Draw top face
            this.ctx.beginPath();
            this.ctx.moveTo(baseCoords.x, topY - this.tileHeight / 2); // Top vertex
            this.ctx.lineTo(baseCoords.x + this.tileWidth / 2, topY); // Right vertex
            this.ctx.lineTo(baseCoords.x, topY + this.tileHeight / 2); // Bottom vertex
            this.ctx.lineTo(baseCoords.x - this.tileWidth / 2, topY); // Left vertex
            this.ctx.closePath();

            const styles = getComputedStyle(document.body);
            let color = styles.getPropertyValue('--color-restaurant-base').trim();
            
            this.ctx.fillStyle = color;
            this.ctx.fill();
            this.ctx.strokeStyle = 'rgba(0,0,0,0.5)';
            this.ctx.stroke();
            
            // Draw left face
            this.ctx.beginPath();
            this.ctx.moveTo(baseCoords.x - this.tileWidth / 2, topY);
            this.ctx.lineTo(baseCoords.x, topY + this.tileHeight / 2);
            this.ctx.lineTo(baseCoords.x, baseCoords.y + this.tileHeight / 2); // Down to base
            this.ctx.lineTo(baseCoords.x - this.tileWidth / 2, baseCoords.y); // Back to base left
            this.ctx.closePath();
            this.ctx.fillStyle = '#cc3333'; // Darker red
            this.ctx.fill();
            this.ctx.stroke();

            // Draw right face
            this.ctx.beginPath();
            this.ctx.moveTo(baseCoords.x + this.tileWidth / 2, topY);
            this.ctx.lineTo(baseCoords.x, topY + this.tileHeight / 2);
            this.ctx.lineTo(baseCoords.x, baseCoords.y + this.tileHeight / 2); // Down to base
            this.ctx.lineTo(baseCoords.x + this.tileWidth / 2, baseCoords.y); // Back to base right
            this.ctx.closePath();
            this.ctx.fillStyle = '#992222'; // Darkest red
            this.ctx.fill();
            this.ctx.stroke();
        }
        
        // Draw ID on top
        const topBaseCoords = this.getScreenCoords(rest.x, rest.y, rest.floors);
        const textY = topBaseCoords.y - this.floorHeight; // center of the top face
        
        this.ctx.fillStyle = 'white';
        this.ctx.font = 'bold 16px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.textBaseline = 'middle';
        this.ctx.fillText(`#${rest.id}`, topBaseCoords.x, textY);
    }
}
