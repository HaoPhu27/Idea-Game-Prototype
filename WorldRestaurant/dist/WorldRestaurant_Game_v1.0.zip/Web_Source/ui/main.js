import { LevelLoader } from '../engine/LevelLoader.js';
import { GameRules } from '../engine/GameRules.js';
import { IsometricRenderer } from '../renderer/IsometricRenderer.js';
import { InputHandler } from './InputHandler.js';
import { CommandHistory } from '../engine/CommandHistory.js';

class GameApp {
    constructor() {
        this.state = null;
        this.renderer = null;
        this.inputHandler = null;
        this.history = null;

        // UI elements
        this.levelNameEl = document.getElementById('level-name');
        this.cloudLimitEl = document.getElementById('cloud-limit');
        this.gameOverScreen = document.getElementById('game-over-screen');
        this.gameOverTitle = document.getElementById('game-over-title');
        this.levelMenu = document.getElementById('level-menu');
        this.btnNextLevel = document.getElementById('btn-next-level');
        this.btnRetry = document.getElementById('btn-retry');
        this.btnViewBoard = document.getElementById('btn-view-board');
        this.btnBackToResults = document.getElementById('btn-back-to-results');
        this.btnMenuFromGameOver = document.getElementById('btn-menu-from-gameover');
        
        // Splash & Guide elements
        this.splashScreen = document.getElementById('splash-screen');
        this.splashLoadingBarContainer = document.getElementById('splash-loading-bar-container');
        this.splashLoadingBar = document.getElementById('splash-loading-bar');
        this.splashLoadingText = document.getElementById('splash-loading-text');
        this.splashActionButtons = document.getElementById('splash-action-buttons');
        this.btnSplashPlay = document.getElementById('btn-splash-play');
        this.btnSplashGuide = document.getElementById('btn-splash-guide');
        this.btnSplashLevels = document.getElementById('btn-splash-levels');
        
        this.guideModal = document.getElementById('guide-modal');
        this.btnCloseGuide = document.getElementById('btn-close-guide');
        this.btnCloseGuideX = document.getElementById('btn-close-guide-x');
        this.btnOpenGuide = document.getElementById('btn-open-guide');
        
        this.btnNextLevel.addEventListener('click', () => this.nextLevel());
        this.btnRetry.addEventListener('click', () => this.retryLevel());
        this.btnMenuFromGameOver.addEventListener('click', () => {
            this.gameOverScreen.classList.add('hidden');
            this.openMenu();
        });
        this.btnViewBoard.addEventListener('click', () => {
            this.gameOverScreen.classList.add('hidden');
            this.btnBackToResults.classList.remove('hidden');
        });
        this.btnBackToResults.addEventListener('click', () => {
            this.btnBackToResults.classList.add('hidden');
            this.gameOverScreen.classList.remove('hidden');
        });
        document.getElementById('btn-open-menu').addEventListener('click', () => this.openMenu());
        document.getElementById('btn-close-menu').addEventListener('click', () => this.closeMenu());
        
        if (this.btnOpenGuide) this.btnOpenGuide.addEventListener('click', () => this.openGuide());
        if (this.btnCloseGuide) this.btnCloseGuide.addEventListener('click', () => this.closeGuide());
        if (this.btnCloseGuideX) this.btnCloseGuideX.addEventListener('click', () => this.closeGuide());
        
        if (this.btnSplashPlay) {
            this.btnSplashPlay.addEventListener('click', () => {
                this.splashScreen.classList.add('hidden');
            });
        }
        if (this.btnSplashGuide) {
            this.btnSplashGuide.addEventListener('click', () => {
                this.openGuide();
            });
        }
        if (this.btnSplashLevels) {
            this.btnSplashLevels.addEventListener('click', () => {
                this.splashScreen.classList.add('hidden');
                this.openMenu();
            });
        }

        document.querySelectorAll('.btn-level').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const lvl = parseInt(e.target.dataset.level, 10);
                const padded = String(lvl).padStart(3, '0');
                this.loadLevel(`levels/level_${padded}.json`);
                this.closeMenu();
                if (this.splashScreen) this.splashScreen.classList.add('hidden');
            });
        });
        
        // Add Undo Button to HUD dynamically
        this.undoBtn = document.createElement('button');
        this.undoBtn.textContent = 'Undo (3)';
        this.undoBtn.style.margin = '0';
        this.undoBtn.style.padding = '6px 12px';
        this.undoBtn.style.fontSize = '14px';
        this.undoBtn.onclick = () => this.handleUndo();
        document.querySelector('#hud > div:nth-child(2)').appendChild(this.undoBtn);

        this.currentLevelUrl = 'levels/level_001.json';
        this.init();
    }

    openGuide() {
        if (this.guideModal) this.guideModal.classList.remove('hidden');
    }

    closeGuide() {
        if (this.guideModal) this.guideModal.classList.add('hidden');
    }

    async init() {
        const canvas = document.getElementById('game-canvas');
        const container = document.getElementById('game-container');
        
        this.renderer = new IsometricRenderer(canvas, container);
        this.inputHandler = new InputHandler(this.handleMove.bind(this));
        
        // Run loading animation
        this.simulateLoading();

        await this.loadLevel(this.currentLevelUrl);
    }

    simulateLoading() {
        if (!this.splashLoadingBar) return;
        
        let progress = 0;
        const interval = setInterval(() => {
            progress += Math.floor(Math.random() * 25) + 15;
            if (progress >= 100) {
                progress = 100;
                clearInterval(interval);
                this.splashLoadingBar.style.width = '100%';
                this.splashLoadingText.textContent = 'Bếp đã sẵn sàng!';
                setTimeout(() => {
                    if (this.splashLoadingBarContainer) this.splashLoadingBarContainer.style.display = 'none';
                    if (this.splashLoadingText) this.splashLoadingText.style.display = 'none';
                    if (this.splashActionButtons) this.splashActionButtons.classList.remove('hidden');
                }, 300);
            } else {
                this.splashLoadingBar.style.width = `${progress}%`;
                if (progress > 50) this.splashLoadingText.textContent = 'Đang tải 20 công thức bàn cờ...';
            }
        }, 80);
    }

    async loadLevel(url) {
        this.currentLevelUrl = url;
        this.state = await LevelLoader.loadLevelJSON(url);
        this.history = new CommandHistory(3); // Allow 3 undos per level

        if (this.state) {
            this.gameOverScreen.classList.add('hidden');
            this.updateHUD();
            this.render();
        }
    }

    openMenu() {
        this.levelMenu.classList.remove('hidden');
        this.gameOverScreen.classList.add('hidden');
    }

    closeMenu() {
        this.levelMenu.classList.add('hidden');
    }

    nextLevel() {
        const currentMatch = this.currentLevelUrl.match(/level_(\d+)/);
        if (currentMatch) {
            let nextNum = parseInt(currentMatch[1], 10) + 1;
            if (nextNum <= 20) {
                const padded = String(nextNum).padStart(3, '0');
                this.loadLevel(`levels/level_${padded}.json`);
                return;
            }
        }
        this.gameOverTitle.textContent = 'You beat all 20 levels! 🎉';
    }

    retryLevel() {
        this.loadLevel(this.currentLevelUrl);
    }

    handleMove(direction) {
        if (!this.state || this.state.phase !== 'moving') return;

        const oldState = this.state.clone();
        const result = GameRules.applyMove(this.state, direction);
        
        if (result) {
            // Save history
            this.history.push({ stateBefore: oldState, direction });
            
            this.state = result.newState;
            // TODO: handle events (AnimationManager)
            this.updateHUD();
            this.render();
            this.checkGameEnd();
        } else {
            console.log("Invalid move!");
        }
    }

    handleUndo() {
        if (this.history && this.history.canUndo()) {
            const prevState = this.history.undo();
            if (prevState) {
                this.state = prevState;
                this.gameOverScreen.classList.add('hidden'); // Hide if we undid from a lose state
                this.updateHUD();
                this.render();
            }
        }
    }

    checkGameEnd() {
        if (this.state.phase === 'win') {
            this.gameOverTitle.textContent = 'Level Complete!';
            this.gameOverTitle.style.color = '#ffd700';
            this.gameOverScreen.classList.remove('hidden');
        } else if (this.state.phase === 'lose') {
            this.gameOverTitle.textContent = 'Game Over';
            this.gameOverTitle.style.color = '#ff5555';
            this.gameOverScreen.classList.remove('hidden');
        }
    }

    updateHUD() {
        if (!this.state) return;
        this.levelNameEl.textContent = "Level " + parseInt(this.state.id || "1", 10);
        this.cloudLimitEl.textContent = this.state.cloudLimit;
        this.undoBtn.disabled = !this.history.canUndo();
        this.undoBtn.textContent = `Undo (${this.history.maxUndo - this.history.undoCount})`;
    }

    render() {
        if (this.state && this.renderer) {
            this.renderer.render(this.state);
        }
    }
}

// Start the app when DOM is ready
if (document.readyState === 'loading') {
    window.addEventListener('DOMContentLoaded', () => new GameApp());
} else {
    new GameApp();
}
