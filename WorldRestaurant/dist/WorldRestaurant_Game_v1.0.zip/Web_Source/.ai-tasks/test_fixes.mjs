import { CommandHistory } from '../engine/CommandHistory.js';
import { GameState } from '../engine/GameState.js';

const h = new CommandHistory(3);
for (let i = 1; i <= 4; i++) h.push({ stateBefore: 'state' + i });
console.log('after 4 pushes: stack=', h.stack.length, 'canUndo=', h.canUndo(), 'undosLeft=', h.undosLeft);
console.log('undo1 ->', h.undo(), 'left=', h.undosLeft, 'canUndo=', h.canUndo());
console.log('undo2 ->', h.undo(), 'left=', h.undosLeft);
console.log('undo3 ->', h.undo(), 'left=', h.undosLeft, 'canUndo=', h.canUndo());
console.log('undo4 (should be null) ->', h.undo());
h.clear();
console.log('after clear: canUndo=', h.canUndo(), 'undosLeft=', h.undosLeft, 'undoCount=', h.undoCount);

const s = new GameState();
s.id = '7';
s.name = 'Test Level';
s.movesRemaining = 12;
s.grid = [['L', 'L'], ['L', 'L']];
s.restaurants = [{ id: 1, x: 0, y: 0, floors: 1, parentId: null }];
const c = s.clone();
console.log('clone id=', c.id, 'name=', c.name, 'movesRemaining=', c.movesRemaining, 'w/h=', c.width, c.height);
console.log('deep copy ok:', c.grid !== s.grid && c.grid[0] !== s.grid[0], c.restaurants[0] !== s.restaurants[0]);
